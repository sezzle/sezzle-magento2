/*
 * @category    Sezzle
 * @package     Sezzle_Sezzlepay
 * @copyright   Copyright (c) Sezzle (https://www.sezzle.com/)
 */
var config = {
    map: {
        '*': {
            widgetRenderer: 'Sezzle_Sezzlepay/js/widget-renderer',
        }
    }
};
