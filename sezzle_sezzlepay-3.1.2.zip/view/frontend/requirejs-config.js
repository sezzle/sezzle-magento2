/*
 * @category    Sezzle
 * @package     Sezzle_Sezzlepay
 * @copyright   Copyright (c) Sezzle (https://www.sezzle.com/)
 */
var config = {
    map: {
        '*': {
            productWidget: 'Sezzle_Sezzlepay/js/product-widget',
        }
    }
};
