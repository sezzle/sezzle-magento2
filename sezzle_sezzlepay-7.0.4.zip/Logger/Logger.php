<?php

namespace Sezzle\Sezzlepay\Logger;

/*
 * Logger
 */
class Logger extends \Monolog\Logger
{
}
